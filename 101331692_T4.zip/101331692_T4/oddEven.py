# Start

# Initialize variable
user_Number = 0

# Prompt user input
user_Number = int(input("Please Enter a integer: "))

# Check if Even or Odd
if (user_Number % 2 == 0):
    print("Your number is Even")
else:
    print("Your number is Odd")
    
# End